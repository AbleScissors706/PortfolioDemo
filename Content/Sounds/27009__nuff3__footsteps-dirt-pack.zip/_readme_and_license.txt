Sound pack downloaded from Freesound
----------------------------------------

"Footsteps-Dirt Pack"

This pack of sounds contains sounds by the following user:
 - nuFF3 ( https://freesound.org/people/nuFF3/ )

You can find this pack online at: https://freesound.org/people/nuFF3/packs/27009/


Licenses in this pack (see below for individual sound licenses)
---------------------------------------------------------------

Attribution 4.0: https://creativecommons.org/licenses/by/4.0/


Sounds in this pack
-------------------

  * 477396__nuff3__steps-dirt-2b.ogg
    * url: https://freesound.org/s/477396/
    * license: Attribution 4.0
  * 477395__nuff3__steps-dirt-3a.ogg
    * url: https://freesound.org/s/477395/
    * license: Attribution 4.0
  * 477394__nuff3__steps-dirt-3b.ogg
    * url: https://freesound.org/s/477394/
    * license: Attribution 4.0
  * 477393__nuff3__steps-dirt-falling-1a.ogg
    * url: https://freesound.org/s/477393/
    * license: Attribution 4.0
  * 477392__nuff3__steps-dirt-1a.ogg
    * url: https://freesound.org/s/477392/
    * license: Attribution 4.0
  * 477391__nuff3__steps-dirt-1b.ogg
    * url: https://freesound.org/s/477391/
    * license: Attribution 4.0
  * 477390__nuff3__steps-dirt-2a.ogg
    * url: https://freesound.org/s/477390/
    * license: Attribution 4.0


